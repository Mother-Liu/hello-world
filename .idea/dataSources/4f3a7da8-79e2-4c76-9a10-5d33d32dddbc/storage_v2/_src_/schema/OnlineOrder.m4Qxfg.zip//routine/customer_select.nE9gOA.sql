create
    definer = root@localhost procedure customer_select(IN min int)
BEGIN
SELECT * FROM customer WHERE shopcredits > min;
END;

