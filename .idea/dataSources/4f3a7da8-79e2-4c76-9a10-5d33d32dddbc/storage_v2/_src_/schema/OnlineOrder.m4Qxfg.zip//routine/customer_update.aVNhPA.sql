create
    definer = root@localhost procedure customer_update(IN min int)
BEGIN
DECLARE _id INT;
DECLARE s INT DEFAULT 0;
DECLARE curs CURSOR FOR SELECT id FROM customer;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET s = 1;
OPEN curs;
FETCH curs INTO _id;
WHILE s<>1 DO
UPDATE customer SET shopcredits = shopcredits + 1 WHERE id = _id;
FETCH curs INTO _id;
END WHILE;
CLOSE curs;
END;

