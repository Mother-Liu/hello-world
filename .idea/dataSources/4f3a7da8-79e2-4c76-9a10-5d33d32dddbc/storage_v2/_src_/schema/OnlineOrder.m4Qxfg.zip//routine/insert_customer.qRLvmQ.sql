create
    definer = root@localhost procedure insert_customer(IN start int(10), IN max_num int(10))
begin 
 declare i int default 0;
 set autocommit = 0;
 repeat
 set i = i + 1;
  insert into customer(shopcredits,name,address)
  values((start+i),rand_string(10),rand_string(8));
 until i = max_num
 end repeat;
 commit;
end;

