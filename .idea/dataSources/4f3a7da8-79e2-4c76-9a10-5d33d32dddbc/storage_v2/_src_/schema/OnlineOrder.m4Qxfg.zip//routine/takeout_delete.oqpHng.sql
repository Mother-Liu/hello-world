create
    definer = root@localhost procedure takeout_delete(IN min int)
BEGIN
DELETE FROM takeout WHERE price < min;
END;

