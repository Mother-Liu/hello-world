create
    definer = root@localhost function rand_num() returns int(5)
begin  
   declare i int default 0;
   set i = floor(100 + rand()*20);
 return i;
end;

