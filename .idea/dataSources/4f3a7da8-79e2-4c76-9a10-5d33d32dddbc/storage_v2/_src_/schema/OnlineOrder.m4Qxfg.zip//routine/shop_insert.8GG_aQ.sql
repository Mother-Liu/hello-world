create
    definer = root@localhost procedure shop_insert(IN shopva varchar(1000))
BEGIN
DECLARE str VARCHAR(1000) CHARACTER SET utf8;
SET str = CONCAT('INSERT INTO shop VALUES(',shopva,')');
SET @sql1 = str;
PREPARE smt_shop_insert FROM @sql1;
EXECUTE smt_shop_insert;
END;

