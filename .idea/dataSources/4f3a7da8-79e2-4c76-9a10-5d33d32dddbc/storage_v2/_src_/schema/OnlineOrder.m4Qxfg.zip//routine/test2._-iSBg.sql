create
    definer = root@localhost procedure test2()
BEGIN
DECLARE _id INT;
DECLARE s INT DEFAULT 0;
DECLARE curs CURSOR FOR SELECT id FROM customer;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET s = 1;
OPEN curs;
FETCH curs INTO _id;
WHILE s<>1 DO
SELECT * FROM customer WHERE id=_id;
FETCH curs INTO _id;
END WHILE;
CLOSE curs;
END;

